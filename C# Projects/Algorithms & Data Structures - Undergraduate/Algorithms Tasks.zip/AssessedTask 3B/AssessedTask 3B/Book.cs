﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssessedTask_3B
{
    public class Book : IComparable<Book>
    {
        //Get and Set methods for each variable 
        public string Title { get; set; }
        public string Author { get; set; }
        public int Publication_Year { get; set; }

        // Implements an IComparable<Book> interface for future sorting
        public int CompareTo(Book other)
        {
            // Sort by the Publication Year
            return this.Publication_Year.CompareTo(other.Publication_Year);
        }
    }

    public class SelectionSort
    {
        public static void SelectSortGen<T>(T[] a) where T : IComparable<T>
        {
            for (int i = 0; i < a.Length - 1; i++)
            {
                int smallest = i;
                for (int j = i + 1; j < a.Length; j++)
                {
                    if (a[j].CompareTo(a[smallest]) < 0)
                        smallest = j;
                }
                Swap(ref a[i], ref a[smallest]);
            }
        }

        private static void Swap<T>(ref T x, ref T y)
        {
            T temp = x;
            x = y;
            y = temp;
        }
    }


}
