﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssessedTask_3B
{
    class Program
    {
        static void Main()
        {
            // Sorts an array of integers in order
            int[] intArray = { 8, 1000, 4, 21, 3, 7, 9, 23 };
            SelectionSort.SelectSortGen(intArray);
            Console.WriteLine("Sorted Array of Integers:");
            foreach (var item in intArray)
            {
                Console.Write(item + " ");
            }
            Console.WriteLine();

            // Sorts an array of Book objects
            Book[] books = new Book[]
            {
            new Book { Title = "Of Mice And Men", Author = "John Steinbeck", Publication_Year = 1937 },
            new Book { Title = "Wuthering Heights", Author = "Emily Bronte", Publication_Year = 1847 },
            new Book { Title = "Normal People", Author = "Sally Rooney", Publication_Year = 2018 },
            new Book { Title = "Pride And Prejudice", Author = "Jane Austen", Publication_Year = 1813 },
            new Book { Title = "The Fault In Our Stars", Author = "John Green", Publication_Year = 2012 },
            new Book { Title = "The Great Gatsby", Author = "F Scott Fitzgerald", Publication_Year = 1925 }
            };

            SelectionSort.SelectSortGen(books);
            Console.WriteLine("\nSorted Array of Books by Publication Year:");
            foreach (var book in books)
            {
                Console.WriteLine($"Title: {book.Title}, Author: {book.Author}, Publication Year: {book.Publication_Year}");
            }

            // Keeps the console open until a key is pressed
            Console.ReadLine();
        }
    }
}
