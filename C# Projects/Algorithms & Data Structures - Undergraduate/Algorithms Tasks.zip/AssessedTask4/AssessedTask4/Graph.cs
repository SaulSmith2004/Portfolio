﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssessedTask4
{
    public class Graph<T> where T : IComparable //IComparable makes the graph class generic
    {

        //A List of GraphNodes in the graph (nodes in the graph)
        //Member
        private LinkedList<GraphNode<T>> nodes;

        //Constructor
        public Graph()
        {
            nodes = new LinkedList<GraphNode<T>>();
        }

        //True or False to check if Graph is Empty
        public bool IsEmptyGraph()
        {
            return nodes.Count == 0;
        }

        //Adds a new node in the graph. Use constructor of graphnode
        public void AddNode(T id)
        {
            nodes.AddLast(new GraphNode<T>(id));
        }

        //True or False for Whether the Graph contains a node
        public bool ContainsGraph(GraphNode<T> node)
        {

            //Validation to be completed: add a check that node is not null
            foreach (GraphNode<T> n in nodes)
            {
                if (n.ID.CompareTo(node.ID) == 0)
                {
                    return true;
                }
            }

            return false;
        }

        //Gets Node via the 'ID'
        public GraphNode<T> GetNodeByID(T id)
        {
            foreach (GraphNode<T> n in nodes)
            {
                if (id.CompareTo(n.ID) == 0) return n;
            }
            return null;
        }

        //Checks who is Adjacent
        public bool IsAdjacent(GraphNode<T> from, GraphNode<T> to)
        {

            foreach (GraphNode<T> n in nodes)
            {

                if (n.ID.CompareTo(from.ID) == 0) //Compares the ID to 'from' if it is = to 0, then returns false 
                {
                    if (from.GetAdjList().Contains(to.ID)) //If ID contains a to.ID, then return true
                        return true;
                }

            }

            return false;
        }


        //Returns the total number of nodes present in the graph
        public int NumNodesGraph()
        {

            return nodes.Count;

        }

        //Number of Edges in the Graph
        public int NumEdgesGraph()
        {

            int counteredges = 0;
            foreach (GraphNode<T> n in nodes)
            {
                counteredges += n.GetAdjList().Count;
            }

            return counteredges;

        }

        //Adds Edges to Graph
        public void AddEdge(T from, T to, int weight)
        {
            GraphNode<T> fromNode = GetNodeByID(from);
            GraphNode<T> toNode = GetNodeByID(to);

            if (fromNode != null && toNode != null)
            {
                fromNode.AddEdge(to, weight);
            }
            else
            {
                Console.WriteLine("One or both nodes not present!");
            }
        }

        //Calculates Average Connectivity
        public float AvgConnectivity()
        {
            return NumEdgesGraph() / NumNodesGraph();

        }

        //Collects Degree Centrality
        public float DegreeCentrality(T NodeID)
        {
            GraphNode<T> node = GetNodeByID(NodeID);
            return (float)node.GetAdjList().Count / (float)(NumNodesGraph() - 1);//(float) casts to a float, node.GetAdjList().Count gets the number of nodes from adjacency list

        }

        //Iterates through Nodes
        public IEnumerable<GraphNode<T>> GetNodes()
        {
            return nodes;
        }

        //Gets the Average Outbound Connections
        public float GetAverageOutboundConnections()
        {
            int totalConnections = 0;
            foreach (GraphNode<T> node in nodes)
            {
                totalConnections += node.GetAdjList().Count;
            }
            return (float)totalConnections / NumNodesGraph();
        }

        //Finds Average Edge Weight
        public float GetAverageEdgeWeight()
        {
            int totalWeights = 0;
            int count = 0;
            foreach (GraphNode<T> node in nodes)
            {
                foreach (int weight in node.getWeights())
                {
                    totalWeights += weight;
                    count++;
                }
            }
            return count > 0 ? (float)totalWeights / count : 0;
        }

        //Collects the Node with the Most Outbound Connections
        public T GetNodeWithMostOutboundConnections()
        {
            int maxConnections = 0;
            T nodeWithMaxConnections = default;

            foreach (GraphNode<T> node in nodes)
            {
                if (node.GetAdjList().Count > maxConnections)
                {
                    maxConnections = node.GetAdjList().Count;
                    nodeWithMaxConnections = node.ID;
                }
            }
            return nodeWithMaxConnections;
        }

        //Finds and Displays the Individual who has the most Frequent Communication
        public T GetIndividualWithMostFrequentCommunication()
        {
            int maxWeight = 0;
            T individualWithMaxFreqComm = default;

            foreach (GraphNode<T> node in nodes)
            {
                int totalWeight = 0;
                foreach (int weight in node.getWeights())
                {
                    totalWeight += weight;
                }
                if (totalWeight > maxWeight)
                {
                    maxWeight = totalWeight;
                    individualWithMaxFreqComm = node.ID;
                }
            }
            return individualWithMaxFreqComm;
        }

        //Gets the Messages sent to each Individual
        public List<T> GetSentMessagesToIndividual(T individual)
        {
            List<T> sentMessages = new List<T>();

            foreach (GraphNode<T> node in nodes)
            {
                if (node.ID.Equals(individual))
                {
                    foreach (T to in node.GetAdjList())
                    {
                        sentMessages.Add(to);
                    }
                    break;
                }
            }
            return sentMessages;
        }

        //Removes the Individual from Graph
        public void RemoveIndividual(T id)
        {
            foreach (GraphNode<T> node in nodes)
            {
                if (node.ID.Equals(id))
                {
                    nodes.Remove(node);
                    break;
                }
            }
            foreach (GraphNode<T> node in nodes)
            {
                node.RemoveIndividual(id);
            }
        }

        //Starting Point for finding Individuals
        public List<T> GetReachableIndividuals(T startingPoint)
        {
            foreach (GraphNode<T> node in nodes)
            {
                if (node.ID.Equals(startingPoint))
                {
                    return node.GetReachableIndividuals(startingPoint);
                }
            }
            return new List<T>(); // Return an empty list if starting point not found
        }



    }
}
