﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssessedTask4
{
    internal class Program
    {
        static Graph<string> myGraph = new Graph<string>(); // Define the graph as a global variable

        //Allows a user to insert a Name into the Graph as an 'Individual'
        static void InsertNewIndividual()
        {
            Console.Write("Enter the name of the individual: ");
            string individualName = Console.ReadLine();
            myGraph.AddNode(individualName);
            Console.WriteLine($"Individual '{individualName}' added as a node.");
        }

        //Inserts a Directed Edge into the Graph
        static void InsertDirectedEdge()
        {
            Console.Write("Enter the ID of the source node: ");
            string fromNode = Console.ReadLine();
            Console.Write("Enter the ID of the destination node: ");
            string toNode = Console.ReadLine();
            myGraph.AddEdge(fromNode, toNode, 1); // Assuming weight as 1 for simplicity
            Console.WriteLine($"Directed edge added from '{fromNode}' to '{toNode}'.");
        }

        //Displays Numbers of Individuals Entered
        static void DisplayNumberOfIndividuals()
        {
            Console.WriteLine($"Number of individuals (nodes) in the graph: {myGraph.NumNodesGraph()}");
        }

        //Displays the Number of Edges within the Graph 
        static void DisplayNumberOfEdges()
        {
            Console.WriteLine($"Number of edges in the graph: {myGraph.NumEdgesGraph()}");
        }

        //Allows User to Choose which Individual they want to Remove
        static void RemoveIndividualFromNetwork()
        {
            Console.Write("Enter the name of the individual to remove: ");
            string individualName = Console.ReadLine();
            myGraph.RemoveIndividual(individualName);
            Console.WriteLine($"Individual '{individualName}' removed from the network.");
            Console.WriteLine(); // Add line break
        }

        //Displays Reachable Individuals within the Graph
        static void DisplayReachableIndividuals()
        {
            Console.Write("Enter the name of the individual as the starting point: ");
            string startingPoint = Console.ReadLine();
            List<string> reachableIndividuals = myGraph.GetReachableIndividuals(startingPoint);
            Console.WriteLine($"Individuals that can be reached from '{startingPoint}':");
            foreach (string individual in reachableIndividuals)
            {
                Console.WriteLine(individual);
            }
            Console.WriteLine(); // Add line break
        }



        //Displays the Statistics of the Program e.g. Outbound Connections
        static void DisplayStatistics()
        {
            Console.WriteLine($"Average Number of Outbound Connections between Individuals: {myGraph.GetAverageOutboundConnections()}");
            Console.WriteLine(); // Add line break

            Console.WriteLine($"Average Weight of Edges within the Network: {myGraph.GetAverageEdgeWeight()}");
            Console.WriteLine(); // Add line break

            Console.WriteLine($"Individual with the Most Outbound Connections: {myGraph.GetNodeWithMostOutboundConnections()}");
            Console.WriteLine(); // Add line break

            Console.WriteLine($"Individual who Communicates most Frequently with Friends: {myGraph.GetIndividualWithMostFrequentCommunication()}");
            Console.WriteLine(); // Add line break

            Console.Write("Enter the Name of an Individual to see Sent Messages: ");
            string individualName = Console.ReadLine();
            List<string> sentMessages = myGraph.GetSentMessagesToIndividual(individualName);
            Console.WriteLine($"Names {individualName} has sent messages to: ");
            foreach (string sentTo in sentMessages)
            {
                Console.WriteLine(sentTo);
            }
            Console.WriteLine(); // Add line break
        }




        static void Main(string[] args)
        {
            bool exit = false;

            while (!exit)
            {
                Console.WriteLine("Graph Operations:"); //Gives user a list of choices that they can do by entering the relevant number
                Console.WriteLine("1. Insert a new Individual as a Node");
                Console.WriteLine("2. Insert a Directed Edge between two Nodes");
                Console.WriteLine("3. Display the current Number of Individuals (Nodes) in the Graph");
                Console.WriteLine("4. Display the Current Number of Edges in the Graph");
                Console.WriteLine("5. Remove an Individual from the Network");
                Console.WriteLine("6. Display Reachable Individuals from a given Starting Point");
                Console.WriteLine("7. Display Statistics");
                Console.WriteLine("8. Exit");
                Console.WriteLine();

                Console.Write("Enter your choice: "); //Asks user to input a choice
                int choice;
                if (!int.TryParse(Console.ReadLine(), out choice))
                {
                    Console.WriteLine("Invalid Input! Please enter a number."); //Requests a correct input if wrong info entered
                    continue;
                }

                //Goes through various cases depending on number entered
                switch (choice)
                {
                    case 1:
                        InsertNewIndividual();
                        break;

                    case 2:
                        InsertDirectedEdge();
                        break;

                    case 3:
                        DisplayNumberOfIndividuals();
                        break;

                    case 4:
                        DisplayNumberOfEdges();
                        break;

                    case 5:
                        RemoveIndividualFromNetwork();
                        break;

                    case 6:
                        DisplayReachableIndividuals();
                        break;

                    case 7:
                        DisplayStatistics();
                        break;

                    case 8:
                        exit = true;
                        break;

                    default:
                        Console.WriteLine("Invalid choice! Please enter a Valid Option.");
                        break;
                }

                DisplayStatistics();

                Console.WriteLine();
            }
        }
    }
}


