﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssessedTask4
{
    public class GraphNode<T> //<T> signifies it is generic
    {

        //Members:
        private T id;// data stored in the node. can think like the (unique) "label" of the node

        private LinkedList<T> adjList; // adjacent list of the node
        private LinkedList<int> weights;

        //Setter and Getter:
        public T ID
        {
            set { this.id = value; }
            get { return this.id; }

        }

        //LinkedList gets the AdjacencyList
        public LinkedList<T> GetAdjList()
        {
            return this.adjList;
        }

        //Removes Individual
        public void RemoveIndividual(T id)
        {
            adjList.Remove(id);
        }

        //Graph Node initializer of Graph Node class
        public GraphNode(T id)
        {
            this.id = id;
            adjList = new LinkedList<T>();
            weights = new LinkedList<int>();
        }

        //Adds an edge 
        public void AddEdge(T to, int weight)
        {
            adjList.AddLast(to);
            weights.AddLast(weight);
        }

        //Returns the weights
        public LinkedList<int> getWeights()
        {
            return weights;
        }

        //Gets the Average Edge Weight
        public float GetAverageEdgeWeight()
        {
            if (weights.Count == 0) return 0;

            float totalWeight = 0;
            foreach (int weight in weights)
            {
                totalWeight += weight;
            }
            return totalWeight / weights.Count;
        }

        //Finds the Reachable Individuals 
        public List<T> GetReachableIndividuals(T startingPoint)
        {
            List<T> reachableIndividuals = new List<T>();
            Queue<T> queue = new Queue<T>();
            HashSet<T> visited = new HashSet<T>();

            queue.Enqueue(startingPoint);
            visited.Add(startingPoint);

            while (queue.Count > 0)
            {
                T current = queue.Dequeue();
                reachableIndividuals.Add(current);

                foreach (T neighbor in adjList)
                {
                    if (!visited.Contains(neighbor))
                    {
                        queue.Enqueue(neighbor);
                        visited.Add(neighbor);
                    }
                }
            }
            return reachableIndividuals;
        }



    }

}


