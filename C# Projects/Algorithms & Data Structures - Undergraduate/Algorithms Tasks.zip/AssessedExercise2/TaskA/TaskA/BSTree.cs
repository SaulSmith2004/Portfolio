﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TaskA
{
    public class BSTree<T> : BinTree<T> where T : IComparable<T>
    {
        public new Node<T> root;

        public BSTree() : base()
        {
            root = null;
        }

        public void InsertItem(T item) //Inserts an Item into Tree
        {
            root = Insert(root, item);
        }

        private Node<T> Insert(Node<T> node, T item) //Inserts new Nodes into Tree
        {
            if (node == null)
                return new Node<T>(item);

            if (item.CompareTo(node.Data) < 0)
                node.Left = Insert(node.Left, item);
            else if (item.CompareTo(node.Data) > 0)
                node.Right = Insert(node.Right, item);

            return node;
        }

        public bool SearchItem(T item) //Searches for Item
        {
            return Search(root, item);
        }

        private bool Search(Node<T> node, T item) //Checks if Node is null during search, if not null then Search is performed
        {
            if (node == null)
                return false;

            if (node.Data.CompareTo(item) == 0)
                return true;
            else if (node.Data.CompareTo(item) > 0)
                return Search(node.Left, item);
            else
                return Search(node.Right, item);
        }

        public int GetHeight()//Gets Tree Height by calculating it
        {
            return CalculateHeight(root);
        }

        private int CalculateHeight(Node<T> node)//Method for calculating height of tree
        {
            if (node == null)
                return 0;

            int leftHeight = CalculateHeight(node.Left);
            int rightHeight = CalculateHeight(node.Right);

            return Math.Max(leftHeight, rightHeight) + 1;
        }

        public void RemoveItem(T item)
        {
            root = Remove(root, item);
        }

        private Node<T> Remove(Node<T> node, T item)
        {
            if (node == null)
                return node;

            if (item.CompareTo(node.Data) < 0)
            {
                node.Left = Remove(node.Left, item);
            }
            else if (item.CompareTo(node.Data) > 0)
            {
                node.Right = Remove(node.Right, item);
            }
            else
            {
                if (node.Left == null)
                    return node.Right;
                else if (node.Right == null)
                    return node.Left;

                node.Data = FindMinValue(node.Right);
                node.Right = Remove(node.Right, node.Data);
            }

            return node;
        }

        private T FindMinValue(Node<T> node)
        {
            T minVal = node.Data;
            while (node.Left != null)
            {
                minVal = node.Left.Data;
                node = node.Left;
            }
            return minVal;
        }


    }


}
