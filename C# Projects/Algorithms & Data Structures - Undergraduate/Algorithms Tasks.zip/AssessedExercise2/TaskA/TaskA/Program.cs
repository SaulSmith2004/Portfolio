﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TaskA
{
    internal class Program
    {
        private static BSTree<string> tree = new BSTree<string>();

        static void Main(string[] args)
        {
            InitializeTree(); // Insert initial items into the tree

            while (true)
            {
                DisplayMenu();
                string option = Console.ReadLine();

                switch (option) //Switch for each operation e.g. TreeHeight displays Tree Height
                {
                    case "1":
                        MainConsoleItem();
                        break;
                    case "2":
                        CheckForConsoleItem();
                        break;
                    case "3":
                        ChooseTraversal();
                        break;
                    case "4":
                        TreeHeight();
                        break;
                    case "5":
                        Environment.Exit(0);
                        break;
                    case "6":
                        RemoveWord();
                        break;
                    default:
                        Console.WriteLine("Invalid option. Please select a valid option.");
                        break;
                }
            }
        }

        private static void InitializeTree()
        {
            
        }

        private static void DisplayMenu() //Menu to choose which option they would like, each performing different operations
        {
            Console.Clear();
            Console.WriteLine("Choose an option:");
            Console.WriteLine("1) Enter Name");
            Console.WriteLine("2) Check For Name");
            Console.WriteLine("3) Choose Tree Traversal");
            Console.WriteLine("4) Display Tree Height");
            Console.WriteLine("5) Exit");
            Console.WriteLine("6) Remove a Word");
            Console.Write("\r\nSelect an option: ");
        }

        private static void MainConsoleItem()
        {
            Console.Clear();//Clears the line before allowing next line to write 
            Console.WriteLine("Input Name");//Asks user to input name into tree
            string name = Console.ReadLine();
            tree.InsertItem(name); //Name is entered into tree
            Console.WriteLine($"Name '{name}' inserted into the tree."); //Condirms name has been entered
            Console.ReadKey();
        }

        private static void CheckForConsoleItem()
        {
            Console.Clear();//Clears the line before allowing next line to write 
            Console.WriteLine("Check For Name (Enter Name)"); //Asks user to enter a name to see if present
            string name = Console.ReadLine();
            bool isPresent = tree.SearchItem(name); //Checks if it 'isPresent' in tree
            Console.WriteLine($"Name '{name}' {(isPresent ? "is" : "is not")} present in the tree.");
            Console.ReadKey();
        }

        private static void ChooseTraversal()//Allows user to choose a traversal
        {
            Console.Clear();
            Console.WriteLine("Choose Tree Traversal:"); //Gives user options of which Traversal Works
            Console.WriteLine("1) In-order");
            Console.WriteLine("2) Pre-order");
            Console.WriteLine("3) Post-order");
            Console.Write("\r\nSelect an option: ");

            string traversalOption = Console.ReadLine(); //Accepts Users Choice

            Console.Clear();
            string buffer = "";

            switch (traversalOption)//Switch for which Traversal is Chosen
            {
                case "1":
                    Console.WriteLine("In-order Traversal:");
                    InOrderTraversal(tree.root, ref buffer);
                    Console.WriteLine($"In-order traversal result: {buffer}");
                    break;
                case "2":
                    Console.WriteLine("Pre-order Traversal:");
                    PreOrderTraversal(tree.root, ref buffer);
                    Console.WriteLine($"Pre-order traversal result: {buffer}");
                    break;
                case "3":
                    Console.WriteLine("Post-order Traversal:");
                    PostOrderTraversal(tree.root, ref buffer);
                    Console.WriteLine($"Post-order traversal result: {buffer}");
                    break;
                default:
                    Console.WriteLine("Invalid option. Please select a valid traversal option.");
                    break;
            }

            Console.ReadKey();
        }

        private static void InOrderTraversal(Node<string> node, ref string buffer)//In Order Traversal Code 
        {
            if (node != null)
            {
                InOrderTraversal(node.Left, ref buffer);
                buffer += node.Data.ToString() + ",";
                InOrderTraversal(node.Right, ref buffer);
            }
        }

        private static void PreOrderTraversal(Node<string> node, ref string buffer)//Pre Order Traversal Code
        {
            if (node != null)
            {
                buffer += node.Data.ToString() + ",";
                PreOrderTraversal(node.Left, ref buffer);
                PreOrderTraversal(node.Right, ref buffer);
            }
        }

        private static void PostOrderTraversal(Node<string> node, ref string buffer)//Post Order Traversal Code
        {
            if (node != null)
            {
                PostOrderTraversal(node.Left, ref buffer);
                PostOrderTraversal(node.Right, ref buffer);
                buffer += node.Data.ToString() + ",";
            }
        }

        private static void TreeHeight()//Method for Displaying the Height of the Tree
        {
            Console.Clear();//Clears the line before allowing next line to write 
            Console.WriteLine("Display Tree Height");
            int height = tree.GetHeight(); //Gets the Tree Height
            Console.WriteLine($"Tree height is: {height}");//Displays Tree Height
            Console.ReadKey();
        }

        private static void RemoveWord()
        {
            Console.Clear();
            Console.WriteLine("Enter the word to remove:");
            string wordToRemove = Console.ReadLine();

            tree.RemoveItem(wordToRemove);
            Console.WriteLine($"Word '{wordToRemove}' removed from the tree.");
            Console.ReadKey();
        }


    }

}