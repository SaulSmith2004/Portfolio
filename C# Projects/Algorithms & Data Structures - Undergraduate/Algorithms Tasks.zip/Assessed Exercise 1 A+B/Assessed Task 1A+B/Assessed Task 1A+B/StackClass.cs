﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assessed_Task_1A_B
{
    internal class StackClass
    {
        private const int maxsize = 10;
        private int top = 0;
        private int[] array = new int[maxsize]; //this is stack

        public void Push(int value)
        {
            array[top++] = value;
        }

        public int Pop()
        {

            return array[top--];

        }

        public int Peek()
        {
            return array[top - 1];
        }

        public bool IsEmpty()
        {
            return top == 0;
        }

        public bool IsFull()
        {
            return top == maxsize;
        }

        public string ToString()
        {
            string buffer = "";
            for (int i = 0; i < top; i++)
            {
                buffer += array[i].ToString() + ", ";
            }
            return buffer;
        }


        //Task B - Sort the Stack
        public void SortStack()
        {
            Array.Sort(array, 0, top);

            //if statement for array being empty 

            // Check if the array is empty
            if (array.Length == 0)
            {
                Console.WriteLine("The array is empty");
            }
            else
            {
                //Console.WriteLine("The stack contains the following elements:");
                foreach (var item in array)
                {
                    Console.WriteLine("The stack contains the following elements:", item);
                }
            }


        }




    }
}
