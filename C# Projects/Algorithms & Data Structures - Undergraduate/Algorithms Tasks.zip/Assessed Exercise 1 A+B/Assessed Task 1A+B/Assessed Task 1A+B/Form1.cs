﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assessed_Task_1A_B
{
    public partial class Form1 : Form
    {

        StackClass MyStack = new StackClass();
        public Form1()
        {
            InitializeComponent();
        }

        

        private void button1_Click(object sender, EventArgs e) //Button Event Handler that controls adding to the stack
        {
            if (!MyStack.IsFull() ) //If statement that says if the total amount is less than 10 numbers, add a number to the stack 
            {
                if (int.TryParse(textBox1.Text, out int value))
                {
                    MyStack.Push(value);
                    textBox1.Clear(); //Clears text box
                    label1.Text = "Pushed " + value + " to the stack."; //Confirms Stack Addition
                    textBox1.Clear();
                }
                else
                {
                    label1.Text = "Invalid input. Please enter an integer.";
                }
            }
            else
            {
                label1.Text = "Stack is full. Cannot push.";
            }
        }

        private void button2_Click(object sender, EventArgs e) //Event Handler for Removing Numbers from Stack 
        {
            if (!MyStack.IsEmpty() ) //If Statement that checks stack has more than 1 value, to enable 'Pops'
            {
                int value = MyStack.Pop();
                label1.Text = "Popped " + value + " from the stack."; //Confirms Pop/Int Removal
            }
            else
            {
                label1.Text = "Stack is empty. Cannot pop.";
            }

        }

        private void button3_Click(object sender, EventArgs e) //Displays current numbers within the stack
        {
            label1.Text = "Stack: " + string.Join(", ", MyStack.ToString());
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (!MyStack.IsEmpty())
            {
                MyStack.SortStack();
                RefreshStackDisplay();
            }
            else
            {
                MessageBox.Show("Stack is empty. Nothing to sort.");
            }
        }

        private void RefreshStackDisplay()
        {
            label1.Text = MyStack.ToString();
        }

    }
}
