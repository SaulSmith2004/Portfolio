/*
 * MPI-converted driver for calculating statistics and dominant eigenvalue
 * (modifies only the driver; autogenRoutines.c remains unchanged)
 *
 * (c) mkbane (Nov 2024 - Jan 2026) - converted to MPI by assistant
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <mpi.h>

// function prototypes (do NOT modify these; provided in autogenRoutines.c)
int get_num_data_points(FILE*);
int read_data(FILE*, int, double*, double*);  // returns number of points successfully read

int main(int argc, char** argv) {
  int rank, size;
  MPI_Init(&argc, &argv);
  MPI_Comm_rank(MPI_COMM_WORLD, &rank);
  MPI_Comm_size(MPI_COMM_WORLD, &size);

  double startTotalCode = MPI_Wtime();

  if (argc < 2) {
    if (rank == 0) fprintf(stderr, "Usage: %s datafile\n", argv[0]);
    MPI_Finalize();
    return -1;
  }

  FILE* filePtr = NULL;
  int totalNum = 0;
  int n = 0;
  double *x = NULL;
  double *A = NULL;
  double *squaredDiffs = NULL;

  if (rank == 0) {
    char *filename = argv[1];
    filePtr = fopen(filename, "r");
    if (filePtr == NULL) {
      fprintf(stderr, "Cannot open file %s\n", filename);
      MPI_Abort(MPI_COMM_WORLD, 1);
    }
    // Master reads header count
    totalNum = get_num_data_points(filePtr);
    printf("There are allegedly %d data points to read\n", totalNum);
  }

  // Broadcast totalNum from master to all ranks so they can allocate
  MPI_Bcast(&totalNum, 1, MPI_INT, 0, MPI_COMM_WORLD);
  if (totalNum <= 0) {
    if (rank == 0) fprintf(stderr, "Invalid totalNum: %d\n", totalNum);
    MPI_Finalize();
    return -1;
  }

  // Allocate buffers on all ranks (size = totalNum) so they can receive data
  x = (double *) malloc(totalNum * sizeof(double));
  A = (double *) malloc((size_t)totalNum * (size_t)totalNum * sizeof(double));
  if (x == NULL || A == NULL) {
    if (rank == 0) fprintf(stderr, "Error allocating memory for x or A\n");
    MPI_Abort(MPI_COMM_WORLD, 2);
  }

  if (rank == 0) {
    double start_readData = MPI_Wtime();
    n = read_data(filePtr, totalNum, x, A); // master reads actual n and fills x, A
    if (n == -1) {
      fprintf(stderr, "error during read_data; aborting\n");
      MPI_Abort(MPI_COMM_WORLD, 3);
    }
    printf("%d data points successfully read [%f seconds]\n", n, MPI_Wtime()-start_readData);
    if (n != totalNum) printf("*** WARNING ***\n actual number read (%d) differs from header value (%d)\n\n", n, totalNum);
    fclose(filePtr);
  }

  // Broadcast actual n to all ranks (master determined actual number read)
  MPI_Bcast(&n, 1, MPI_INT, 0, MPI_COMM_WORLD);
  if (n <= 0) {
    if (rank == 0) fprintf(stderr, "Invalid n: %d\n", n);
    MPI_Finalize();
    return -1;
  }

  // Broadcast the vector x and matrix A (only n and n*n elements used)
  MPI_Bcast(x, n, MPI_DOUBLE, 0, MPI_COMM_WORLD);
  MPI_Bcast(A, n * n, MPI_DOUBLE, 0, MPI_COMM_WORLD);

  // allocate squaredDiffs only on ranks that need it (we'll use local partial sums instead)
  squaredDiffs = (double *) malloc(n * sizeof(double));
  if (squaredDiffs == NULL) {
    if (rank == 0) fprintf(stderr, "Error allocating memory for squaredDiffs\n");
    MPI_Abort(MPI_COMM_WORLD, 4);
  }

  if (rank == 0) printf("x[0]=%f\n", x[0]);

  double start = MPI_Wtime();
  double local_start = MPI_Wtime();

  // (i) calc mean using distributed reduction
  // compute partition for this rank
  int base = n / size;
  int rem = n % size;
  int local_n = base + (rank < rem ? 1 : 0);
  int *counts = (int*) malloc(size * sizeof(int));
  int *displs = (int*) malloc(size * sizeof(int));
  if (!counts || !displs) {
    if (rank == 0) fprintf(stderr, "Allocation failed for counts/displs\n");
    MPI_Abort(MPI_COMM_WORLD, 5);
  }
  int offset = 0;
  for (int r = 0; r < size; r++) {
    counts[r] = base + (r < rem ? 1 : 0);
    displs[r] = offset;
    offset += counts[r];
  }
  int start_idx = displs[rank];
  int end_idx = start_idx + counts[rank]; // exclusive

  double local_sum = 0.0;
  for (int i = start_idx; i < end_idx; i++) local_sum += x[i];

  double sum = 0.0;
  MPI_Reduce(&local_sum, &sum, 1, MPI_DOUBLE, MPI_SUM, 0, MPI_COMM_WORLD);

  double mean = 0.0;
  if (rank == 0) mean = sum / (double) n;
  // broadcast mean to all ranks so they can compute squared diffs locally
  MPI_Bcast(&mean, 1, MPI_DOUBLE, 0, MPI_COMM_WORLD);

  // each rank computes local squaredDiffs sum for its partition
  double local_sqsum = 0.0;
  for (int i = start_idx; i < end_idx; i++) {
    double val = (x[i] - mean);
    squaredDiffs[i] = val * val;
    local_sqsum += squaredDiffs[i];
  }

  double total_sqsum = 0.0;
  MPI_Reduce(&local_sqsum, &total_sqsum, 1, MPI_DOUBLE, MPI_SUM, 0, MPI_COMM_WORLD);

  double variance = 0.0;
  if (rank == 0) variance = total_sqsum / (double) n;

  // (ii) calc min,max of absolute values using reductions
  // compute local min and max of fabs(x)
  double local_minabs = fabs(x[start_idx]);
  double local_maxabs = fabs(x[start_idx]);
  for (int i = start_idx+1; i < end_idx; i++) {
    double v = fabs(x[i]);
    if (v < local_minabs) local_minabs = v;
    if (v > local_maxabs) local_maxabs = v;
  }
  double minabs = 0.0, maxabs = 0.0;
  MPI_Reduce(&local_minabs, &minabs, 1, MPI_DOUBLE, MPI_MIN, 0, MPI_COMM_WORLD);
  MPI_Reduce(&local_maxabs, &maxabs, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD);

  if (rank == 0) printf("Time for vector stats: %f seconds\n", MPI_Wtime()-local_start);

  // (iii) calc eigenvalue of matrix A using distributed rows (power iteration)
  if (rank == 0) printf("calculating eigenvalue");
  local_start = MPI_Wtime();

  double *approx = (double*) malloc(n * sizeof(double));
  double *z = (double*) malloc(n * sizeof(double));
  double *local_z = (double*) malloc(local_n * sizeof(double));
  double *err = (double*) malloc(n * sizeof(double));
  if (!approx || !z || !local_z || !err) {
    if (rank == 0) fprintf(stderr, "Error allocating memory for eigen computation\n");
    MPI_Abort(MPI_COMM_WORLD, 6);
  }

  for (int i = 0; i < n; i++) approx[i] = 1.0;

  double tol = 0.01;
  int iterCount = 0;
  double zmax = 0.0;
  double errmax = 0.0;

  // main power-iteration loop
  if (rank == 0) printf(" to tolerance %f\n", tol);
  do {
    iterCount++;
    double iterStart = MPI_Wtime();

    // Each rank computes its local rows of z = A * approx
    // A is stored column-major in original indexing pos_ij = i + n*j (i row, j col)
    for (int local_i = 0; local_i < local_n; local_i++) {
      int i_global = start_idx + local_i;
      double accum = 0.0;
      // compute dot product of row i_global of A with approx
      // A[i + n*j] = element (i, j)
      for (int j = 0; j < n; j++) {
        int pos_ij = i_global + n * j;
        accum += A[pos_ij] * approx[j];
      }
      local_z[local_i] = accum;
    }

    // find local maximum absolute value in local_z
    double local_zmax = 0.0;
    if (local_n > 0) {
      local_zmax = fabs(local_z[0]);
      for (int ii = 1; ii < local_n; ii++) {
        double av = fabs(local_z[ii]);
        if (av > local_zmax) local_zmax = av;
      }
    }
    // get global zmax
    MPI_Allreduce(&local_zmax, &zmax, 1, MPI_DOUBLE, MPI_MAX, MPI_COMM_WORLD);

    // normalize local_z by global zmax
    if (zmax != 0.0) {
      for (int ii = 0; ii < local_n; ii++) local_z[ii] /= zmax;
    }

    // gather all local_z into full z on all ranks
    MPI_Allgatherv(local_z, counts[rank], MPI_DOUBLE, z, counts, displs, MPI_DOUBLE, MPI_COMM_WORLD);

    // compute local errmax comparing fabs(z) and fabs(approx) on local partition
    double local_errmax = 0.0;
    if (local_n > 0) {
      local_errmax = fabs(fabs(z[start_idx]) - fabs(approx[start_idx]));
      for (int ii = start_idx+1; ii < end_idx; ii++) {
        double e = fabs(fabs(z[ii]) - fabs(approx[ii]));
        if (e > local_errmax) local_errmax = e;
      }
    }
    // reduce to global errmax
    MPI_Allreduce(&local_errmax, &errmax, 1, MPI_DOUBLE, MPI_MAX, MPI_COMM_WORLD);

    // update approx to z (z is full on all ranks)
    for (int i = 0; i < n; i++) approx[i] = z[i];

    // DEBUG timing per iteration (only root prints)
    if (rank == 0) {
      //printf("Iteration %d has error %g (%f seconds)\n", iterCount, errmax, MPI_Wtime() - iterStart);
    }
  } while (errmax > tol);

  if (rank == 0) printf("Time for eigen stats: %f seconds\n", MPI_Wtime()-local_start);

  if (rank == 0) {
    printf("Total stats wallclock time [%f seconds]\n", MPI_Wtime()-start);
    printf("Stats table\n");
    printf("Min abs val\tMax abs val\tMean\t\tStd Dev\n");
    printf("%f\t %f\t %f\t\t %f\n", minabs, maxabs, mean, sqrt(variance));
    printf("Eigen value of matrix: %f (%d iterations)\n", zmax, iterCount);
  }

  // cleanup
  free(x);
  free(A);
  free(squaredDiffs);
  free(approx);
  free(z);
  free(local_z);
  free(err);
  free(counts);
  free(displs);

  if (rank == 0) printf("Completed (read+stats). [%f seconds]\n", MPI_Wtime()-startTotalCode);

  MPI_Finalize();
  return 0;
}
