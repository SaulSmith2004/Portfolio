document.addEventListener("DOMContentLoaded", function () {
    const driverInput = document.getElementById("driver-team");
    const driverSuggestionsBox = document.getElementById("suggestions");

    const trackInput = document.getElementById("track");
    const trackSuggestionsBox = document.getElementById("track-suggestions");

    //Driver Search Function
    function searchDrivers() {
        let input = driverInput.value.trim();
        if (input.length < 2) {
            driverSuggestionsBox.style.display = "none";
            return;
        }

        //Queries the Driver
        fetch(`/search_drivers?query=${input}`)
            .then(response => response.json())
            .then(data => {
                driverSuggestionsBox.innerHTML = "";
                if (data.length === 0) {
                    driverSuggestionsBox.style.display = "none";
                    return;
                }

                //Retrieves Data
                data.forEach(driver => {
                    let listItem = document.createElement("li");
                    listItem.textContent = driver;
                    listItem.classList.add("suggestion-item");
                    listItem.onclick = function () {
                        driverInput.value = driver;
                        driverSuggestionsBox.style.display = "none";
                    };
                    driverSuggestionsBox.appendChild(listItem);
                });

                driverSuggestionsBox.style.display = "block";
            })
            .catch(error => console.error("❌ Driver Fetch Error: " + error));
    }

    //Function for Searching Tracks
    function searchTracks() {
        let input = trackInput.value.trim();
        if (input.length < 1) {
            trackSuggestionsBox.style.display = "none";
            return;
        }

        //Searches Tracks and waits for input
        fetch(`/search_tracks?query=${input}`)
            .then(response => response.json())
            .then(data => {
                trackSuggestionsBox.innerHTML = "";
                if (data.length === 0) {
                    trackSuggestionsBox.style.display = "none";
                    return;
                }

                //Retrieves and Selects a Track
                data.forEach(track => {
                    let listItem = document.createElement("li");
                    listItem.textContent = track;
                    listItem.classList.add("suggestion-item");
                    listItem.onclick = function () {
                        trackInput.value = track;
                        trackSuggestionsBox.style.display = "none";
                    };
                    trackSuggestionsBox.appendChild(listItem);
                });

                trackSuggestionsBox.style.display = "block";
            })
            .catch(error => console.error("❌ Track Fetch Error: " + error));
    }

    //Logic for Search Functions
    driverInput.addEventListener("keyup", searchDrivers);

    trackInput.addEventListener("focus", searchTracks);
    trackInput.addEventListener("keyup", searchTracks);

    document.addEventListener("click", function (event) {
        if (!driverInput.contains(event.target) && !driverSuggestionsBox.contains(event.target)) {
            driverSuggestionsBox.style.display = "none";
        }
        if (!trackInput.contains(event.target) && !trackSuggestionsBox.contains(event.target)) {
            trackSuggestionsBox.style.display = "none";
        }
    });
});

//JS Logic for selecting the nav bar
document.addEventListener('DOMContentLoaded', function () {
    const menuBtn = document.getElementById('menu-btn');
    const mobileNav = document.querySelector('.mobile-navbar');

    if (menuBtn && mobileNav) {
        menuBtn.addEventListener('click', function () {
            mobileNav.classList.toggle('active');
            this.classList.toggle('fa-bars');
            this.classList.toggle('fa-times');
        });
    }
});

//JS for the Mobile Navbar 
document.querySelectorAll('.mobile-navbar a').forEach(link => {
    link.addEventListener('click', () => {
        mobileNav.classList.remove('active');
    });
});



    













