import os
import pandas as pd

# Path to your folder with weather CSVs
weather_folder = os.path.join("data", "weather_raw")

combined_data = []

for filename in os.listdir(weather_folder):
    if filename.endswith(".csv"):
        filepath = os.path.join(weather_folder, filename)
        try:
            df = pd.read_csv(filepath)

            # Attempt to extract track name from filename
            track_name = filename.replace(".csv", "")
            df["Track"] = track_name

            # Optionally extract year if not already present
            if "date" in df.columns:
                df["date"] = pd.to_datetime(df["date"], errors='coerce')
                df["Year"] = df["date"].dt.year

            combined_data.append(df)

        except Exception as e:
            print(f"❌ Failed to process {filename}: {e}")

# Combine and save
if combined_data:
    full_weather = pd.concat(combined_data, ignore_index=True)
    full_weather.to_csv("data/weather_data.csv", index=False)
    print("✅ All weather data combined into data/weather_data.csv")
else:
    print("⚠️ No weather files found or combined.")
