import os
import pandas as pd
from flask import Flask, render_template, request, jsonify

app = Flask(__name__)

# Load CSV's safely
def load_csv(file_name):
    file_path = os.path.join("data", file_name)
    return pd.read_csv(file_path) if os.path.exists(file_path) else None

# Working Routes, for page linking to html
@app.route('/')
def home():
    return render_template('index.html')

@app.route('/contact')
def contact():
    return render_template('contact.html')

@app.route('/about')
def about():
    return render_template('about.html')

@app.route('/disclaimer')
def disclaimer():
    import datetime
    return render_template('disclaimer.html', current_year=datetime.datetime.now().year)

@app.route('/stats')
def stats():
    return render_template('stats.html')


# Load Data from CSV Files
drivers_df = load_csv("drivers.csv")
results_df = load_csv("results.csv")
races_df = load_csv("races.csv")
circuits_df = load_csv("circuits.csv")
driver_standings_df = load_csv("driver_standings.csv")
sprint_results_df = load_csv("sprint_results.csv")
status_df = load_csv("status.csv")
champions_df = load_csv("champions.csv")
weather_df = load_csv("weather_data.csv")

# Championship Logic Processing
if champions_df is not None:
    champions_df["Driver"] = champions_df["Driver"].str.replace(r"\s*\(.*?\)", "", regex=True).str.lower()
    driver_championships = champions_df.groupby("Driver")["Year"].apply(list).to_dict()
else:
    driver_championships = {}

# Track Mapping - Mismatched names are now linked for consistency
track_name_mapping = {
    "Silverstone": "Silverstone Circuit",
    "Interlagos": "Autódromo José Carlos Pace",
    "Suzuka": "Suzuka Circuit",
    "Monza": "Autodromo Nazionale di Monza",
    "Spa": "Circuit de Spa-Francorchamps",
    "Hungaroring": "Hungaroring",
    "Zandvoort": "Circuit Zandvoort",
    "Barcelona": "Circuit de Barcelona-Catalunya",
    "Red Bull Ring": "Red Bull Ring",
    "Singapore": "Marina Bay Street Circuit",
    "Monaco": "Circuit de Monaco",
    "Imola": "Autodromo Enzo e Dino Ferrari",
    "Melbourne": "Albert Park Grand Prix Circuit",
    "Bahrain": "Bahrain International Circuit",
    "Jeddah": "Jeddah Corniche Circuit",
    "Austin": "Circuit of the Americas",
    "Mexico City": "Autódromo Hermanos Rodríguez",
    "Abu Dhabi": "Yas Marina Circuit",
    "Las Vegas": "Las Vegas Strip Street Circuit",
    "Miami": "Miami International Autodrome",
    "Qatar": "Lusail International Circuit",
    "Saudi Arabia": "Jeddah Corniche Circuit"
}

# Weather Logic Preprocessing
if weather_df is not None:
    weather_df.rename(columns={"Track": "track", "time": "date"}, inplace=True)
    weather_df["track"] = weather_df["track"].replace(track_name_mapping)
    weather_df["date"] = pd.to_datetime(weather_df["date"], errors="coerce")
    weather_df["year"] = weather_df["date"].dt.year
    weather_df["dominant_weather"] = weather_df["precipitation_sum"].apply(lambda x: "wet" if x > 0 else "dry")

    weather_summary = (
        weather_df.groupby(["track", "year"])["dominant_weather"]
        .agg(lambda x: x.mode()[0] if not x.mode().empty else "unknown")
        .reset_index()
        .rename(columns={"track": "circuit_name"})
    )

    if "circuitId" in races_df.columns and "circuitId" in circuits_df.columns:
        circuits_df = circuits_df.rename(columns={"name": "circuit_name"})
        races_df = races_df.merge(
            circuits_df[["circuitId", "circuit_name"]],
            on="circuitId",
            how="left"
        )

    if "circuit_name" in races_df.columns and "year" in races_df.columns:
        races_df = races_df.merge(
            weather_summary,
            on=["circuit_name", "year"],
            how="left"
        )

# Driver Name Suggestions when typing
@app.route('/search_drivers')
def search_drivers():
    query = request.args.get("query", "").lower()
    if not query or drivers_df is None:
        return jsonify([])
    drivers_df["full_name"] = drivers_df["forename"] + " " + drivers_df["surname"]
    matches = drivers_df[drivers_df["full_name"].str.lower().str.contains(query, na=False)]
    return jsonify(matches["full_name"].tolist())

# Track Name Suggestions when typing
@app.route('/search_tracks')
def search_tracks():
    query = request.args.get("query", "").strip().lower()
    if not query or circuits_df is None:
        return jsonify([])
    if "name" not in circuits_df.columns and "circuit_name" in circuits_df.columns:
        circuits_df["name"] = circuits_df["circuit_name"]
    circuits_df["track_name"] = circuits_df["name"].str.lower()
    matches = circuits_df[circuits_df["track_name"].str.contains(query, na=False)]
    return jsonify(matches["name"].tolist())

# Results Page Outcome with Bayesian Model
@app.route('/results')
def results():
    driver_name = request.args.get("driver", "").strip().lower()
    year = request.args.get("year", "").strip()
    track = request.args.get("track", "").strip().lower()
    weather = request.args.get("weather", "").strip().lower()

    if not driver_name:
        return "❌ ERROR: Please enter a driver name", 400

    drivers_df["full_name"] = (drivers_df["forename"] + " " + drivers_df["surname"]).str.lower()
    driver_row = drivers_df[drivers_df["full_name"].str.contains(driver_name, na=False)]
    if driver_row.empty:
        return "❌ ERROR: Driver not found", 404

    driver_id = str(driver_row.iloc[0]["driverId"])
    driver_full_name = driver_row.iloc[0]["full_name"].title()
    driver_number = driver_row.iloc[0].get("number", "N/A")

    results_df["driverId"] = results_df["driverId"].astype(str)
    driver_results = results_df[results_df["driverId"] == driver_id]
    driver_results = driver_results.merge(races_df, on="raceId", how="left")

    #If Statement for the Year
    if year:
        driver_results = driver_results[driver_results["year"] == int(year)]

    #If Statement for Track Name
    if track:
        circuits_df["track_name"] = circuits_df["name"].str.lower()
        track_row = circuits_df[circuits_df["track_name"].str.contains(track, na=False)]
        if not track_row.empty:
            track_id = track_row.iloc[0]["circuitId"]
            driver_results = driver_results[driver_results["circuitId"] == track_id]

    #If Statement for Weather
    if weather and "dominant_weather" in driver_results.columns:
        driver_results["dominant_weather"] = driver_results["dominant_weather"].astype(str).str.lower().str.strip()
        if weather in ["wet", "dry"]:
            driver_results = driver_results[driver_results["dominant_weather"] == weather]
        elif weather == "unclassified":
            driver_results = driver_results[~driver_results["dominant_weather"].isin(["wet", "dry"])]
        else:
            driver_results = driver_results[driver_results["dominant_weather"].str.contains(weather, na=False)]

    total_races = driver_results.shape[0]
    total_wins = driver_results[driver_results["positionOrder"] == 1].shape[0]
    total_podiums = driver_results[driver_results["positionOrder"] <= 3].shape[0]
    total_points = driver_results["points"].sum()
    total_fastest_laps = driver_results[driver_results["fastestLap"] == 1].shape[0]

    total_dnfs = 0
    if status_df is not None and "statusId" in driver_results.columns:
        driver_results = driver_results.merge(status_df, on="statusId", how="left")
        total_dnfs = driver_results[
            driver_results["status"].str.contains("Accident|Collision|DNF", na=False, case=False)
        ].shape[0]

    years_active = driver_results["year"].unique()
    years_active_display = f"{min(years_active)} - {max(years_active)}" if len(years_active) else "N/A"

    championship_years = driver_championships.get(driver_full_name.lower(), [])
    total_titles = len(championship_years)
    titles_display = "0" if total_titles == 0 else ", ".join(map(str, championship_years))

    # ✅ Bayesian Win Probability
    global_avg_win_rate = results_df[results_df["positionOrder"] == 1].shape[0] / results_df.shape[0]
    alpha = 5  # how many "prior" races we're assuming
    bayesian_win_rate = ((alpha * global_avg_win_rate) + total_wins) / (alpha + total_races) if total_races > 0 else 0
    bayesian_win_percent = round(bayesian_win_rate * 100, 2)

    #Places all of these calculations into the Results.html page
    return render_template(
        'results.html',
        driver=driver_full_name,
        total_wins=total_wins,
        total_podiums=total_podiums,
        total_points=total_points,
        total_races=total_races,
        total_fastest_laps=total_fastest_laps,
        total_titles=titles_display,
        total_dnfs=total_dnfs,
        driver_number=driver_number,
        years_active=years_active_display,
        weather=weather if weather else "All",
        bayesian_win_percent=bayesian_win_percent
    )

if __name__ == '__main__':
    app.run(debug=True)
