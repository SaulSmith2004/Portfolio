//Hero Class 

class Hero 

{ 

  int x, y; 

  int speedX=2; 

  int speedY=2; 

  PImage image; 

  Hero(int x, int y) 

  { 
    
    this.x = x; 

    this.y = y; 
    
    image = loadImage("Hero.png"); 

  } 

//methods, procedures an object of this type can perform 

void render() 

{ 

  image(image, x, y);

} 

void update() 

  { 

  this.move(); 

  this.render(); 
  
  } 

void move() 

{ 

  //x = x+speedX; 

} 

boolean crash() 

{ 

  stroke(255,255,0); 

  for(int i = 0; i<30; i++) 

  { 

   color testColour = get(x+65, y+i);  

  if (testColour == Spaceship1 || testColour == Spaceship2) 

   return true; //green was detected 

    } 

  return false; 

  } 

 

} 
