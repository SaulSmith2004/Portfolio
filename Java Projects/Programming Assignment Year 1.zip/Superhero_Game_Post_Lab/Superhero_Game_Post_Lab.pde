
float x,y; 

PImage background;  

int bgX=0; //global variable background location 

Spaceship s1; 

Spaceship s2; 

Spaceship s3; 

Hero h1;

Planet p1;
