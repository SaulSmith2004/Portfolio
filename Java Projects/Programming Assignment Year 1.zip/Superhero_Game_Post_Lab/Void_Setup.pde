void setup(){ 

  size(800,400); 
  
  background = loadImage("Background.png"); 

  background.resize(width,height); //set image to be same size as the canvas 

  s1 = new Spaceship(); 

  s2 = new Spaceship(); 

  //s3 = new Spaceship(); 
   
  h1 = new Hero(100,200); 
  
  p1 = new Planet(-70,100);



} 

void draw () 

{ 

  scrollBackground(); 

  s1.update(); 
  
  s2.update(); 

  //s3.update(); 

  h1.update(); 
  
  p1.update();

  if(h1.crash()) 

  print("Hit"); 

} 

void scrollBackground() 

{ 

 image(background, bgX, 0); //draw image to fill the canvas 

 image(background, bgX+background.width, 0); //draw image again off the right of the canvas 

 bgX = bgX- 4; 

 if(bgX == -background.width) //if first image completely off the canvas 

 { 

  bgX=0; //reset back to initial value background 

 } 


} 

void mouseClicked() {

   
  
}
 
 
 

void keyPressed() 

{ 

  if(key == CODED) 

  { 

    if (keyCode == UP && height>=400) 

    { 

      h1.y = h1.y - 5; 

    } 

    if(keyCode == DOWN && height>=0) 

    { 

      h1.y = h1.y + 5; 

    } 

  }  //if key is CODED 

} 

 

//boolean crash(float x, float y) 

//{ 

// color col=get((int)x,(int)y); 

//  if (col==color(0,0,0)) 

//  point(x,y); 
 
