//Planet Class 

class Planet

{

  int x, y;

  int speedX=1;

  int speedY=1;


  PImage image3;


  Planet(int x, int y)

  {

    this.x = x;

    this.y = y;

    image3 = loadImage("Planet.png");
  }

  void render()

  {

    image(image3, x, y);
  }


  void update()

  {

    this.move();

    this.render();
  }

  void move()

  {

    //x = x+speedX;
  }
}
