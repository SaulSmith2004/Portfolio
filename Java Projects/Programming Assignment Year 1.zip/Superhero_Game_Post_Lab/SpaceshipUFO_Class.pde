final color Spaceship1 = color(0,255,0); 

final color Spaceship2 = color(50,100,0); 

//UFO Class 

class Spaceship

{ 
//Members 
int x = 5;  

int y; 

int speed=1; 

int size=30; 

color colour; 

int Spaceship;  

int speedX=2; 

int speedY=2; 

PImage image2;

Spaceship(){ //constructor 

   this.x = width; 

   this.y=(int)random(0,height); 

   this.speedX=(int)random(1,10); 
   
   image2 = loadImage("UFO.png"); 

} 

 

//methods, procedures an object of this type can perform 

void display() 

{ 

  image(image2, x, y);
  

} 

void update()   

{ 

  this.move(); 

  this.display(); 

} 

void move() { 

x= x-speedX; 

if(x < 0) 

{ 

 x=width;  

} 


}  

} 
